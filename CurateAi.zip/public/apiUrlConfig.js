const GENERATE_CONTENT_URL = "/generate-content";
const BASE_URL = "http://localhost:5000"