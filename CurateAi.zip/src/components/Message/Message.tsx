// import { useEffect, useState } from "react";
// import CampaignModal from "../Action/CampaignModal";
// import Breadcrumb from "../Action/Breadcrumb";
// import useCampaigns from "../customHook/useCampaigns"

/**
 * @component
 * @description
 * The `Message` component renders a page header section with navigation breadcrumbs and a dropdown menu. 
 * It includes a title, breadcrumb navigation links, and a campaign selection dropdown, making it ideal 
 * for a "Message" page or similar Message structure.
 *
 * @example
 * <Message />
 *
 * @returns {JSX.Element} The rendered component.
 *
 * @returns {JSX.Element}
 * - Renders a `div` with the main structure for the Message page including:
 *   - Page title with an icon and "Message" label.
 *   - Breadcrumb navigation for Message > Message.
 *   - Dropdown menu for campaign selection.
 *
 * @styles
 * - Utilizes Tailwind CSS classes for layout and styling, with responsive adjustments for smaller screens.
 */
const Message = () => {

  // const [typeValue, setTypeValue] = useState("")
  // // Fetch campaigns data on mount
  // useEffect(() => {
  //   setTypeValue("message")
  //   fetchCampaigns(); // Fetch campaigns on component mount
  // }, []);

  return (
    <>
      <div className="pr-7 c-padding-r pt-16 max-[650px]:pr-3 h-screen w-[84%] relative left-[267px]">
        {/* <Breadcrumb name={'Message'}></Breadcrumb> */}
        <div className="flex justify-between gap-5 w-full">
          <div className="bg-white rounded-2xl w-full">
            {/* <div className="d-global-t">
              <div className="flex justify-between border bordere7e9f6 border-t-0 border-e-0 border-s-0">
                <div className="inputgroup relative flex">
                  <span className="color00517C text-base max-[1350px]:text-sm font-semibold px-5 py-4 block max-[650px]:py-2">Campaign</span>
                </div>
              </div>
            </div> */}
            <div className="px-5 py-4">
              <div className="d-table h-connect-table !w-full">
                <div className="table-hedder flex bge7e9f6 p-4">
                  {/* <div className="flex items-center">
                    <span className="inline-block connect-table-checkbox">
                      <input type="checkbox" className="w-5 h-5 me-3 relative left-1 top-1 outline outline-offset-2 outline-1 border-0 rounded-sm"
                      /></span>
                    <form className="ml-20 flex flex-col gap-5 max-[650px]:gap-3 w-full" onSubmit={(e) => e.preventDefault()}>
                      <div id="searchBar" className="inputgroup relative flex w-80">
                        <input
                          type="text"
                          placeholder="Search campaigns by name..."

                          className="w-full border rounded-2xl outline-0 py-1 px-5 color00517C font-normal text-base max-[1350px]:text-sm "
                        />
                      </div>
                    </form>
                  </div> */}
                  <div className="pt-2 pb-2 bge7e9f6 px-4 ms-auto mr-4">
                    {/* <span className="icon w-4 h-4 block">
                      <img src="../images/listing-page-img/delete.svg" alt="img" className="cursor-pointer w-full h-full" />
                    </span> */}
                  </div>
                </div>
                <table className="w-full border bordere7e9f6 rounded-2xl overflow-auto g-table">
                  <tr>
                    <th className="font-light text-base max-[1350px]:text-sm px-4 border border-t-0 border-s-0 border-e-0 bordere7e9f6 color00517C pt-2 pb-2 w-56">
                      <span className="inline-block connect-table-checkbox float-left relative">
                      </span>
                      <span className="info w-auto block text-left px-5">
                        <span className="font-bold text-base max-[1350px]:text-sm px-4 uppercase">Name</span><br />
                      </span>
                    </th>
                    <th className="font-light text-base max-[1350px]:text-sm px-4 border border-t-0 border-s-0 border-e-0 bordere7e9f6 color00517C pt-2 pb-2 w-56 "><span className="font-bold text-base uppercase">Url</span></th>
                    <th className="font-light text-base max-[1350px]:text-sm px-4 border border-t-0 border-s-0 border-e-0 bordere7e9f6 color00517C pt-2 pb-2 w-56 "><span className="font-bold text-base uppercase">Status</span></th>
                    <th className="font-light text-base max-[1350px]:text-sm px-4 border border-t-0 border-s-0 border-e-0 bordere7e9f6 color00517C pt-2 pb-2 w-56 "><span className="font-bold text-base uppercase">Created At</span></th>
                    <th className="font-light text-base max-[1350px]:text-sm px-4 border border-t-0 border-s-0 border-e-0 bordere7e9f6 color00517C pt-2 pb-2 w-56 "><span className="font-bold text-base uppercase">Last Date</span></th>
                    <th className="font-light text-base max-[1350px]:text-sm px-4 border border-t-0 border-s-0 border-e-0 bordere7e9f6 color00517C pt-2 pb-2 w-56 "><span className="font-bold text-base uppercase">Start - End</span></th>
                    <th className="font-light text-base max-[1350px]:text-sm px-4 border border-t-0 border-s-0 border-e-0 bordere7e9f6 color00517C pt-2 pb-2 w-56 "><span className="font-bold text-base uppercase">Action</span></th>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Message;
